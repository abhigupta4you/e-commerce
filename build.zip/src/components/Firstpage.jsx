import React from 'react'

function Firstpage() {
  return (
    <div>Firstpage</div>
  )
}

export default Firstpage